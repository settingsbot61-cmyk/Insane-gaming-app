InsaneGamingMediafireApp - Android Studio project

Features:
- Splash style main screen with Ben 10 Minecraft background (replace res/drawable/bg_placeholder.png)
- Text: "Subscribe to Insane Gaming"
- Two buttons:
  * Download BE Version -> opens Mediafire BE link
  * Download RE Version -> opens Mediafire RE link
- Credits: Insane Gaming

How to build:
1. Open this folder in Android Studio
2. Sync Gradle
3. Replace background image with Ben 10 + Minecraft theme (res/drawable/bg_placeholder.png)
4. Build > Build APK(s)
5. APK will be in app/build/outputs/apk/
